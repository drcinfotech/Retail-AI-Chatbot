## What this PR does

<!-- One or two sentences describing the change. -->

## Why

<!-- Linked issue, or context if no issue exists. -->

Closes #

## How to test

<!-- Step-by-step manual verification — the exact messages to type, what to look for. -->

## Checklist

- [ ] `python test_chatbot.py` passes (21/21 or more)
- [ ] `npm run build` completes cleanly
- [ ] Added or updated tests for changed behavior
- [ ] Updated README if user-visible behavior changed
- [ ] Manually exercised in the browser
- [ ] No secrets, API keys, or personal data committed

## Screenshots (if UI changed)

<!-- Drag images here. Before/after pairs are most helpful. -->
