---
name: 💡 Feature request
about: Suggest a new capability or improvement
title: "[Feature] "
labels: ["enhancement"]
---

## The idea in one sentence

<!-- What would the bot do that it can't do today? -->

## The problem it solves

<!-- Who would benefit from this and how? An example conversation snippet helps. -->

## Proposed approach (optional)

<!-- If you have a sense of how it could be built — which file would change, what the intent pattern would look like, etc. — share it here. -->

## Alternatives considered

<!-- Other approaches you thought about, and why this one is better. -->

## Additional context

<!-- Screenshots, mockups, links to similar implementations elsewhere. -->
