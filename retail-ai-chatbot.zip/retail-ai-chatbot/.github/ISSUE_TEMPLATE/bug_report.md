---
name: 🐛 Bug report
about: Something isn't working as expected
title: "[Bug] "
labels: ["bug"]
---

## What happened?

<!-- A clear description of the bug. Include the exact message you sent the bot and the response you received. -->

## What did you expect?

<!-- What you expected to happen instead. -->

## Steps to reproduce

1.
2.
3.

## Screenshots / logs

<!-- Drag images here or paste terminal output between ```triple backticks``` -->

## Environment

- OS:
- Python version: <!-- python --version -->
- Node version:   <!-- node --version -->
- Browser:
- Backend running via: [ ] uvicorn directly  [ ] docker compose

## Additional context

<!-- Anything else that might help us debug this. -->
