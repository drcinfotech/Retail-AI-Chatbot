"""Retail AI Chatbot backend package."""
__version__ = "1.0.0"
